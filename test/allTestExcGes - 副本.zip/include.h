#ifndef __INCLUDE_H__
#define __INCLUDE_H__

#include "LQ12864.h"
#include "msp430f5529.h"
void delayms(int ms);

#endif
